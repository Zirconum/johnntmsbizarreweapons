Original weapons (Alternate Crossbow, Alternate Bow Railcannon) by dueris(quocnam201010)
See original packs: https://github.com/bitchsmp/packs
Initially rewritten as a datapack for 1.21.11
Updated to 26.2 as a mod
Added a variety of weapons


- zzzzzzzzz