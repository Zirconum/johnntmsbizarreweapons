tag @s remove bihh_marked
scoreboard players reset @s bihh_dot
scoreboard players reset @s bihh_by
