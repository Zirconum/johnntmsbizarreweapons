scoreboard objectives add bihh_shot minecraft.used:minecraft.bow
scoreboard objectives add bihh_chg dummy
scoreboard objectives add bihh_idle dummy
scoreboard objectives add bihh_cd_rc dummy
scoreboard objectives add bihh_cd_mrc dummy
scoreboard objectives add bihh_tmp dummy
scoreboard objectives add bihh_c dummy
scoreboard players set #2 bihh_c 2
scoreboard players set #4 bihh_c 4
scoreboard players set #20 bihh_c 20
scoreboard objectives add bihh_cd_sd dummy
scoreboard objectives add bihh_id dummy
scoreboard objectives add bihh_by dummy
scoreboard objectives add bihh_dot dummy
scoreboard objectives add bihh_age dummy
