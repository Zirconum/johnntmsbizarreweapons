tag @s add bihh_drill
scoreboard players set @s bihh_age 0
data merge entity @s {NoGravity:1b,PierceLevel:127b,damage:0.0d,pickup:0b}
data modify entity @s item set value {id:"minecraft:tipped_arrow",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:luck"}}}
