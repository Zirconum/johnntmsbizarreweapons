# constants are re-set every tick so a missed load can never break the clocks
scoreboard players set #2 bihh_c 2
scoreboard players set #4 bihh_c 4
scoreboard players set #20 bihh_c 20
# make sure every player has every score
scoreboard players add @a bihh_chg 0
scoreboard players add @a bihh_idle 0
scoreboard players add @a bihh_cd_rc 0
scoreboard players add @a bihh_cd_mrc 0
scoreboard players add @a bihh_cd_sd 0
# cooldowns
scoreboard players remove @a[scores={bihh_cd_rc=1..}] bihh_cd_rc 1
scoreboard players remove @a[scores={bihh_cd_mrc=1..}] bihh_cd_mrc 1
scoreboard players remove @a[scores={bihh_cd_sd=1..}] bihh_cd_sd 1
# shots
execute as @a[scores={bihh_shot=1..}] at @s run function bihhrangedartifacts:on_shot
# charge ended without a shot: no charge_tick for 3 ticks
scoreboard players add @a[scores={bihh_chg=1..}] bihh_idle 1
scoreboard players set @a[scores={bihh_idle=3..}] bihh_chg 0
scoreboard players set @a[scores={bihh_idle=3..}] bihh_idle 0
# clocks
execute store result score #gt bihh_tmp run time query gametime
scoreboard players operation #m4 bihh_tmp = #gt bihh_tmp
scoreboard players operation #m4 bihh_tmp %= #4 bihh_c
scoreboard players operation #m20 bihh_tmp = #gt bihh_tmp
scoreboard players operation #m20 bihh_tmp %= #20 bihh_c
# holding effects
tag @a[predicate=bihhrangedartifacts:holding_any] add bihh_holding
execute as @a[tag=bihh_holding,predicate=!bihhrangedartifacts:holding_any] run function bihhrangedartifacts:unhold
execute as @a[predicate=bihhrangedartifacts:holding_railcannon] at @s run function bihhrangedartifacts:rc_aura
execute as @a[predicate=bihhrangedartifacts:holding_malicious] at @s run function bihhrangedartifacts:mrc_aura
execute if score #m20 bihh_tmp matches 0 as @a[predicate=bihhrangedartifacts:holding_railcannon,scores={bihh_chg=0,bihh_cd_rc=0}] at @s run playsound ultrakill:railcannonfull player @a ~ ~ ~ 0.25 1
execute if score #m20 bihh_tmp matches 0 as @a[predicate=bihhrangedartifacts:holding_malicious,scores={bihh_chg=0,bihh_cd_mrc=0}] at @s run playsound ultrakill:railcannonfull player @a ~ ~ ~ 0.25 1
execute if score #m20 bihh_tmp matches 0 as @a[predicate=bihhrangedartifacts:holding_screwdriver,scores={bihh_chg=0,bihh_cd_sd=0}] at @s run playsound ultrakill:railcannonfull player @a ~ ~ ~ 0.25 1
# screwdriver bow: aura whenever it is held
execute as @a[predicate=bihhrangedartifacts:holding_screwdriver] at @s run function bihhrangedartifacts:sd_aura
# unique id per player (so the damage over time can be credited to the shooter)
execute as @a unless score @s bihh_id matches 1.. run function bihhrangedartifacts:assign_id
# drill projectiles and marked targets
execute as @e[type=arrow,tag=bihh_drill] at @s run function bihhrangedartifacts:drill_tick
tag @a remove bihh_dsh
execute as @e[tag=bihh_marked] at @s run function bihhrangedartifacts:dot_tick
