# runs every tick while a bow is being drawn (advancement reward), as the player
advancement revoke @s only bihhrangedartifacts:using_bow
execute unless predicate bihhrangedartifacts:holding_any run return 0
scoreboard players set @s bihh_idle 0
scoreboard players add @s bihh_chg 1
# first tick of the draw: cut the hold hum, then the click plays first
execute if score @s bihh_chg matches 1 run function bihhrangedartifacts:charge_click
