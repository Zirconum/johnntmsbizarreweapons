execute if score #hit bihh_tmp matches 0 as @e[distance=..1.4,tag=!bihh_dsh,type=!#bihhrangedartifacts:non_targets,limit=1,sort=nearest] run function bihhrangedartifacts:sd_hit
