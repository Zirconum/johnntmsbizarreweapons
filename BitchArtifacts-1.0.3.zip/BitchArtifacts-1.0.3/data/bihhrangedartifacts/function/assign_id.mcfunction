scoreboard players add #next bihh_c 1
scoreboard players operation @s bihh_id = #next bihh_c
