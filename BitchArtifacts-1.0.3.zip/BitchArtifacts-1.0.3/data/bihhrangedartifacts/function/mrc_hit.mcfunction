scoreboard players set #hit bihh_tmp 1
tag @s add bihh_primary
execute at @s run function bihhrangedartifacts:mrc_explode
