execute if score @s bihh_cd_sd matches 1.. run kill @e[type=#minecraft:arrows,distance=..4,limit=1,sort=nearest,nbt={inGround:0b}]
execute if score @s bihh_cd_sd matches 1.. run return 0
scoreboard players set @s bihh_cd_sd 70
stopsound @s * ultrakill:railcannonfull
playsound ultrakill:electric_railcannon player @a ~ ~ ~ 3.75 1
# turn the arrow the bow just shot into the drill: tipped luck arrow, no gravity, no damage of its own
execute as @e[type=arrow,distance=..4,limit=1,sort=nearest,nbt={inGround:0b}] run function bihhrangedartifacts:sd_convert
