# runs as a marked entity, at its position: 0.1 damage per tick, ignores armor and invulnerability frames
scoreboard players remove @s bihh_dot 1
execute if score @s bihh_dot matches ..0 run return run function bihhrangedartifacts:unmark
playsound ultrakill:metal_hit_crash_199 player @a ~ ~ ~ 0.5 1
scoreboard players operation #by bihh_tmp = @s bihh_by
execute as @a if score @s bihh_id = #by bihh_tmp run tag @s add bihh_dsh2
execute if entity @a[tag=bihh_dsh2] run damage @s 0.1 bihhrangedartifacts:screwdriver by @a[tag=bihh_dsh2,limit=1]
execute unless entity @a[tag=bihh_dsh2] run damage @s 0.1 bihhrangedartifacts:screwdriver
tag @a remove bihh_dsh2
