# the vanilla arrow is never wanted
kill @e[type=#minecraft:arrows,distance=..4,limit=1,sort=nearest,nbt={inGround:0b}]
execute if score @s bihh_cd_rc matches 1.. run return 0
scoreboard players set @s bihh_cd_rc 100
stopsound @s * ultrakill:railcannonfull
playsound ultrakill:electric_railcannon player @a ~ ~ ~ 3.75 1
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 1
tag @s add bihh_shooter
scoreboard players set #d bihh_tmp 0
execute anchored eyes positioned ^ ^ ^ anchored feet run function bihhrangedartifacts:rc_ray
tag @e[tag=bihh_hit] remove bihh_hit
tag @s remove bihh_shooter
