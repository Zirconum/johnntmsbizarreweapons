tag @s remove bihh_holding
stopsound @s * ultrakill:railcannonfull
