kill @e[type=#minecraft:arrows,distance=..4,limit=1,sort=nearest,nbt={inGround:0b}]
execute if score @s bihh_cd_mrc matches 1.. run return 0
scoreboard players set @s bihh_cd_mrc 120
stopsound @s * ultrakill:railcannonfull
playsound ultrakill:explosion_2 player @a ~ ~ ~ 3.75 1
tag @s add bihh_shooter
scoreboard players set #d bihh_tmp 0
scoreboard players set #hit bihh_tmp 0
execute anchored eyes positioned ^ ^ ^ anchored feet run function bihhrangedartifacts:mrc_ray
tag @e[tag=bihh_primary] remove bihh_primary
tag @s remove bihh_shooter
