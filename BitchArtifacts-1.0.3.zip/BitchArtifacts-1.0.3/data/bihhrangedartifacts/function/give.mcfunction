# /function bihhrangedartifacts:give  -> gives all three bows to the caller
loot give @s loot bihhrangedartifacts:items/alternate_bow_railcannon
loot give @s loot bihhrangedartifacts:items/malicious_bow_railcannon
loot give @s loot bihhrangedartifacts:items/screwdriver_bow
