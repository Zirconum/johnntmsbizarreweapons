particle raid_omen ~ ~1 ~ 1 0.5 1 0.01 4 force
