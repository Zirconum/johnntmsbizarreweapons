scoreboard players set #hit bihh_tmp 1
# 8 damage on hit
execute if entity @a[tag=bihh_dsh] run damage @s 8 minecraft:arrow by @a[tag=bihh_dsh,limit=1]
execute unless entity @a[tag=bihh_dsh] run damage @s 8 minecraft:arrow
# mark for 450 ticks, remembering who shot it
tag @s add bihh_marked
scoreboard players set @s bihh_dot 450
execute as @a[tag=bihh_dsh,limit=1] run scoreboard players operation #by bihh_tmp = @s bihh_id
scoreboard players operation @s bihh_by = #by bihh_tmp
playsound ultrakill:blueflash player @a ~ ~ ~ 1.5 1
