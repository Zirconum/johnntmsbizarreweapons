# hitscan: stops at the first target (or the first solid block), 40 blocks max
particle dust{color:[1.0,0.0,0.0],scale:1.3} ~ ~ ~ 0.05 0.05 0.05 0 6 force
execute positioned ^ ^ ^0.5 run particle dust{color:[1.0,0.0,0.0],scale:1.3} ~ ~ ~ 0.05 0.05 0.05 0 6 force
execute positioned ~ ~-0.6 ~ as @e[distance=..1.4,tag=!bihh_shooter,type=!#bihhrangedartifacts:non_targets,limit=1,sort=nearest] run function bihhrangedartifacts:mrc_hit
scoreboard players add #d bihh_tmp 1
execute if score #hit bihh_tmp matches 0 if score #d bihh_tmp matches ..40 if block ~ ~ ~ #bihhrangedartifacts:ray_passable positioned ^ ^ ^1 run function bihhrangedartifacts:mrc_ray
