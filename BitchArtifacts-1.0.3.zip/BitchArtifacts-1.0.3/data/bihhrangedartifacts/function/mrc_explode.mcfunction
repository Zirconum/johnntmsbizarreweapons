# primary target: 15 (ray) + 45 (explosion) in one hit so invulnerability frames cannot eat part of it
damage @s 60 minecraft:explosion by @a[tag=bihh_shooter,limit=1]
particle explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
particle flame ~ ~1 ~ 1.5 1 1.5 0.2 40 force
playsound ultrakill:explosion_1 player @a ~ ~ ~ 2 1
# everyone else in the 5x5x3 box around the target: 45
execute positioned ~-2.5 ~-0.5 ~-2.5 as @e[dx=4,dy=2,dz=4,tag=!bihh_shooter,tag=!bihh_primary,type=!#bihhrangedartifacts:non_targets] run damage @s 45 minecraft:explosion by @a[tag=bihh_shooter,limit=1]
