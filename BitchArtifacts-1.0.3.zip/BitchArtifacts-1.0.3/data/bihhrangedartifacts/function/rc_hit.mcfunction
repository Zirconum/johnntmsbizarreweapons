tag @s add bihh_hit
damage @s 40 minecraft:sonic_boom by @a[tag=bihh_shooter,limit=1]
