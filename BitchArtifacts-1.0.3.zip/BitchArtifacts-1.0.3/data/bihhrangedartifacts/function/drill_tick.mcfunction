# runs as the flying arrow, at its position
scoreboard players add @s bihh_age 1
execute if score @s bihh_age matches 100.. run return run kill @s
execute if data entity @s {inGround:1b} run return run kill @s
# dense copper fire + green dust trail
particle copper_fire_flame ~ ~ ~ 0.12 0.12 0.12 0.01 12 force
particle dust{color:[0.2,1.0,0.2],scale:1.3} ~ ~ ~ 0.12 0.12 0.12 0 10 force
particle infested ~ ~ ~ 0.2 0.2 0.2 0.01 4 force
# find the shooter, then sweep the last 2 blocks of flight for a target
execute on origin run tag @s add bihh_dsh
scoreboard players set #hit bihh_tmp 0
function bihhrangedartifacts:sd_scan
execute if score #hit bihh_tmp matches 0 positioned ^ ^ ^-1 run function bihhrangedartifacts:sd_scan
execute if score #hit bihh_tmp matches 0 positioned ^ ^ ^-2 run function bihhrangedartifacts:sd_scan
execute on origin run tag @s remove bihh_dsh
execute if score #hit bihh_tmp matches 1 run kill @s
