execute if predicate bihhrangedartifacts:holding_railcannon run function bihhrangedartifacts:rc_shot
execute if predicate bihhrangedartifacts:holding_malicious run function bihhrangedartifacts:mrc_shot
execute if predicate bihhrangedartifacts:holding_screwdriver run function bihhrangedartifacts:sd_shot
scoreboard players set @s bihh_shot 0
scoreboard players set @s bihh_chg 0
scoreboard players set @s bihh_idle 0
