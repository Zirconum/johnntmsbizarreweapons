particle copper_fire_flame ~ ~1 ~ 1 0.5 1 0.01 4 force
particle dust{color:[0.2,1.0,0.2],scale:1.0} ~ ~1 ~ 1 0.5 1 0 4 force
particle infested ~ ~1 ~ 1 0.5 1 0.01 3 force
