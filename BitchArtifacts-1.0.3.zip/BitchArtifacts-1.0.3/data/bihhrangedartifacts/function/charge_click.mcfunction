stopsound @s * ultrakill:railcannonfull
playsound ultrakill:railcannonfullclick player @a ~ ~ ~ 3.75 1
