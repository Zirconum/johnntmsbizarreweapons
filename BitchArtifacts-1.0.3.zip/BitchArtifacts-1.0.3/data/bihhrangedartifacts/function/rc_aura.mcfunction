particle soul_fire_flame ~ ~1 ~ 1 0.5 1 0.01 4 force
particle flame ~ ~1 ~ 1 0.5 1 0.01 4 force
