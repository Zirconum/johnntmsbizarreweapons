# damage: everything within 1.8 blocks of this point (about 3x3), pierces everything, 23 blocks long
execute positioned ~ ~-0.6 ~ as @e[distance=..1.8,tag=!bihh_shooter,tag=!bihh_hit,type=!#bihhrangedartifacts:non_targets] run function bihhrangedartifacts:rc_hit
# instant visuals
particle flame ~ ~ ~ 0.3 0.3 0.3 0.01 6 force
particle soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.01 6 force
particle electric_spark ~ ~ ~ 0.35 0.35 0.35 0.3 8 force
execute positioned ^ ^ ^0.5 run particle flame ~ ~ ~ 0.3 0.3 0.3 0.01 6 force
execute positioned ^ ^ ^0.5 run particle soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.01 6 force
execute positioned ^ ^ ^0.5 run particle electric_spark ~ ~ ~ 0.35 0.35 0.35 0.3 8 force
scoreboard players operation #m bihh_tmp = #d bihh_tmp
scoreboard players operation #m bihh_tmp %= #2 bihh_c
execute if score #m bihh_tmp matches 0 run particle sonic_boom ~ ~ ~ 0 0 0 0 1 force
scoreboard players add #d bihh_tmp 1
execute if score #d bihh_tmp matches ..23 positioned ^ ^ ^1 run function bihhrangedartifacts:rc_ray
