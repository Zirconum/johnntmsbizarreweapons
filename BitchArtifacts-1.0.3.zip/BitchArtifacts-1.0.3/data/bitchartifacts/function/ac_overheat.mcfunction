# misfire: the crossbow stays loaded, no shot, durability is lost, heat goes up
item modify entity @s weapon.mainhand bitchartifacts:reload_arrow
item modify entity @s weapon.mainhand bitchartifacts:consume_durability
playsound minecraft:entity.wither.break_block player @a ~ ~ ~ 1 1
execute if score @s bitch_heat matches ..698 run scoreboard players add @s bitch_heat 80
title @s actionbar {"text":"OVERHEAT","color":"#ff0000"}
return 0
