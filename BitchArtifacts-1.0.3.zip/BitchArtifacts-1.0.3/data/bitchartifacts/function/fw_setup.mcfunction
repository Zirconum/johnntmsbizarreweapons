data modify entity @s Owner set from entity @a[tag=bitch_shooter,limit=1] UUID
tag @s remove bitch_fw
