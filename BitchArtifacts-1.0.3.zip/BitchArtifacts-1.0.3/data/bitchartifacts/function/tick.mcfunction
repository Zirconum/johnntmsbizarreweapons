scoreboard players set #2 bitch_c 2
scoreboard players set #10 bitch_c 10
execute store result score #gt bitch_tmp run time query gametime
scoreboard players operation #m10 bitch_tmp = #gt bitch_tmp
scoreboard players operation #m10 bitch_tmp %= #10 bitch_c
# alternate crossbow heat
scoreboard players add @a bitch_heat 0
scoreboard players set @a[scores={bitch_heat=..19}] bitch_heat 20
execute if score #m10 bitch_tmp matches 0 run function bitchartifacts:heat_decay
execute as @a[predicate=bitchartifacts:holding_crossbow] run function bitchartifacts:heat_display
# detonator bow: a pending fuse is cancelled by dying, otherwise it counts down and fires
execute as @a[scores={bitch_death=1..}] run scoreboard players set @s bitch_fuse 0
scoreboard players set @a[scores={bitch_death=1..}] bitch_death 0
execute as @a[scores={bitch_fuse=2..}] run scoreboard players remove @s bitch_fuse 1
execute as @a[scores={bitch_fuse=1}] at @s run function bitchartifacts:detonator_fire
