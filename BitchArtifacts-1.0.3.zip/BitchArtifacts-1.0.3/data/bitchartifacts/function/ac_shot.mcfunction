# the vanilla projectile(s) are never wanted: the hitscan replaces them
kill @e[type=#minecraft:arrows,distance=..4,nbt={inGround:0b}]
execute if score @s bitch_heat matches 601.. run return run function bitchartifacts:ac_overheat
tag @s add bitch_shooter
playsound ultrakill:altrevolvershoot1d player @a[distance=..64] ~ ~ ~ 0.25 1 0.25
# damage / piercing tier. #mode = extra blocks the ray keeps going after its first hit
scoreboard players set #dmg bitch_tmp 10
scoreboard players set #mode bitch_tmp 0
scoreboard players set #shield bitch_tmp 0
execute if predicate bitchartifacts:crossbow_piercing_1 run scoreboard players set #dmg bitch_tmp 13
execute if predicate bitchartifacts:crossbow_piercing_1 run scoreboard players set #shield bitch_tmp 1
execute if predicate bitchartifacts:crossbow_piercing_2 run scoreboard players set #dmg bitch_tmp 16
execute if predicate bitchartifacts:crossbow_piercing_2 run scoreboard players set #mode bitch_tmp 13
execute if predicate bitchartifacts:crossbow_piercing_2 run scoreboard players set #shield bitch_tmp 1
execute if predicate bitchartifacts:crossbow_piercing_3 run scoreboard players set #dmg bitch_tmp 19
execute if predicate bitchartifacts:crossbow_piercing_3 run scoreboard players set #mode bitch_tmp 26
execute if predicate bitchartifacts:crossbow_piercing_3 run scoreboard players set #shield bitch_tmp 1
execute if predicate bitchartifacts:crossbow_piercing_4 run scoreboard players set #dmg bitch_tmp 22
execute if predicate bitchartifacts:crossbow_piercing_4 run scoreboard players set #mode bitch_tmp 38
execute if predicate bitchartifacts:crossbow_piercing_4 run scoreboard players set #shield bitch_tmp 1
execute store result storage bitchartifacts:tmp dmg int 1 run scoreboard players get #dmg bitch_tmp
# rays: 1 normally, 3 (centre, +10, -10 degrees) with Multishot
scoreboard players set #multi bitch_tmp 0
execute if predicate bitchartifacts:crossbow_multishot run scoreboard players set #multi bitch_tmp 1
execute if score #multi bitch_tmp matches 0 run function bitchartifacts:ac_ray_start
execute if score #multi bitch_tmp matches 1 run function bitchartifacts:ac_ray_start
execute if score #multi bitch_tmp matches 1 rotated ~10 ~ run function bitchartifacts:ac_ray_start
execute if score #multi bitch_tmp matches 1 rotated ~-10 ~ run function bitchartifacts:ac_ray_start
function bitchartifacts:recoil
return 1
