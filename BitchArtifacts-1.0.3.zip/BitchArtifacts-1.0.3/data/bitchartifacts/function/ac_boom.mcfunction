playsound ultrakill:explosion_2 player @a ~ ~ ~ 4 1
particle explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
execute as @e[distance=..5,tag=!bitch_shooter,type=!#bitchartifacts:non_targets] run damage @s 91.1 minecraft:explosion by @a[tag=bitch_shooter,limit=1]
tag @s remove bitch_shooter
kill @s
