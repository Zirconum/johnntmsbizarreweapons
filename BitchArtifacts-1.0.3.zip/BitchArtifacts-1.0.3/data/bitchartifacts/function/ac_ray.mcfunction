# 1 block cube around this point catches any hitbox it touches; steps are 1 block so cubes overlap
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,tag=!bitch_shooter,tag=!bitch_hit,type=!#bitchartifacts:non_targets] run function bitchartifacts:ac_hit
scoreboard players operation #m bitch_tmp = #d bitch_tmp
scoreboard players operation #m bitch_tmp %= #2 bitch_c
execute if score #m bitch_tmp matches 0 run particle electric_spark ~ ~ ~ 0.05 0.05 0.05 0.05 1 force
scoreboard players add #d bitch_tmp 1
execute if score #d bitch_tmp <= #limit bitch_tmp if block ~ ~ ~ #bitchartifacts:ray_passable positioned ^ ^ ^1 run function bitchartifacts:ac_ray
