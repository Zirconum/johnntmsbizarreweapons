$execute store result storage bitchartifacts:tmp roll.pitch int 1 run random value $(pl)..$(ph)
data modify storage bitchartifacts:tmp roll.yaw set value 0
execute unless data storage bitchartifacts:tmp args{yw:0} run function bitchartifacts:recoil_yaw with storage bitchartifacts:tmp args
function bitchartifacts:recoil_apply with storage bitchartifacts:tmp roll
