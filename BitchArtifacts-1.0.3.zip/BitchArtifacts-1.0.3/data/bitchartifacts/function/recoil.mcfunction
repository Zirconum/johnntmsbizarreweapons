data modify storage bitchartifacts:tmp args set value {pl:0,ph:0,yw:0}
execute if score #multi bitch_tmp matches 0 if score @s bitch_heat matches ..300 run data modify storage bitchartifacts:tmp args set value {pl:-10,ph:-7,yw:0}
execute if score #multi bitch_tmp matches 0 if score @s bitch_heat matches 301..400 run data modify storage bitchartifacts:tmp args set value {pl:-10,ph:-7,yw:5}
execute if score #multi bitch_tmp matches 0 if score @s bitch_heat matches 401..500 run data modify storage bitchartifacts:tmp args set value {pl:-20,ph:-14,yw:5}
execute if score #multi bitch_tmp matches 0 if score @s bitch_heat matches 501.. run data modify storage bitchartifacts:tmp args set value {pl:-20,ph:-14,yw:20}
execute if score #multi bitch_tmp matches 1 if score @s bitch_heat matches ..300 run data modify storage bitchartifacts:tmp args set value {pl:-22,ph:-15,yw:0}
execute if score #multi bitch_tmp matches 1 if score @s bitch_heat matches 301..400 run data modify storage bitchartifacts:tmp args set value {pl:-22,ph:-15,yw:10}
execute if score #multi bitch_tmp matches 1 if score @s bitch_heat matches 401..500 run data modify storage bitchartifacts:tmp args set value {pl:-30,ph:-22,yw:10}
execute if score #multi bitch_tmp matches 1 if score @s bitch_heat matches 501.. run data modify storage bitchartifacts:tmp args set value {pl:-30,ph:-22,yw:35}
function bitchartifacts:recoil_roll with storage bitchartifacts:tmp args
