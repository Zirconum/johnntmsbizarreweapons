tag @s add bitch_hit
execute if score #first bitch_tmp matches 0 run function bitchartifacts:ac_first_hit
execute if score #shield bitch_tmp matches 0 run function bitchartifacts:ac_damage_normal with storage bitchartifacts:tmp
execute if score #shield bitch_tmp matches 1 run function bitchartifacts:ac_damage_pierce with storage bitchartifacts:tmp
# firework burst on the target (alternate_crossbow_firework): area damage, credited to the shooter
execute at @s positioned ~ ~1 ~ run function bitchartifacts:alternate_crossbow_firework
execute as @e[type=minecraft:firework_rocket,tag=bitch_fw] run function bitchartifacts:fw_setup
