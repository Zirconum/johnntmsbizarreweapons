scoreboard objectives add bitch_heat dummy
scoreboard objectives add bitch_fuse dummy
scoreboard objectives add bitch_death deathCount
scoreboard objectives add bitch_tmp dummy
scoreboard objectives add bitch_c dummy
