$damage @s $(dmg) bitchartifacts:alternate_crossbow_pierce by @a[tag=bitch_shooter,limit=1]
