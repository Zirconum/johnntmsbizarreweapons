$execute store result storage bitchartifacts:tmp roll.yaw int 1 run random value -$(yw)..$(yw)
