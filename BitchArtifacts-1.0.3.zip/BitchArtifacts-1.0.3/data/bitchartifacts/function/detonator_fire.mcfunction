# 2 seconds after the shot: the holder detonates
scoreboard players set @s bitch_fuse 0
tag @s add bitch_shooter
function bitchartifacts:ac_boom
