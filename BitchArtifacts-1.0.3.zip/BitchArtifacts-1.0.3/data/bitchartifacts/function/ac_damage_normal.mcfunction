$damage @s $(dmg) bitchartifacts:alternate_crossbow by @a[tag=bitch_shooter,limit=1]
