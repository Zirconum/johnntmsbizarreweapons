# /function bitchartifacts:give
loot give @s loot bitchartifacts:items/alternate_crossbow
loot give @s loot bitchartifacts:items/alternate_crossbow_boom
