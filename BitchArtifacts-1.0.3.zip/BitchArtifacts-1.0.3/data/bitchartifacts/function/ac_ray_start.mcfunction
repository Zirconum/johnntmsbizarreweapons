# every ray adds 40 heat
scoreboard players add @s bitch_heat 40
scoreboard players set #d bitch_tmp 0
scoreboard players set #limit bitch_tmp 1024
scoreboard players set #first bitch_tmp 0
execute anchored eyes positioned ^ ^ ^ anchored feet run function bitchartifacts:ac_ray
# each ray may hit the same target again
tag @e[tag=bitch_hit] remove bitch_hit
