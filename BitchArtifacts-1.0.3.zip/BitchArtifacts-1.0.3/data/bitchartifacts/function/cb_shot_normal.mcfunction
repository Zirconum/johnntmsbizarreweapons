function bitchartifacts:ac_shot
tag @s remove bitch_shooter
