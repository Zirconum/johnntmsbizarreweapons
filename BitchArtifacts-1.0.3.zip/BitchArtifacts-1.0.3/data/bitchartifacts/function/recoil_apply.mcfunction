$rotate @s ~$(yaw) ~$(pitch)
