# lowest tier first so a player is never decayed twice in one pass
scoreboard players remove @a[scores={bitch_heat=21..300}] bitch_heat 2
scoreboard players remove @a[scores={bitch_heat=301..400}] bitch_heat 3
scoreboard players remove @a[scores={bitch_heat=401..500}] bitch_heat 5
scoreboard players remove @a[scores={bitch_heat=501..}] bitch_heat 7
scoreboard players set @a[scores={bitch_heat=..19}] bitch_heat 20
