# remove the vanilla arrow / rocket the crossbow just launched, nothing of the Alternate Crossbow's shot is used
kill @e[type=#minecraft:arrows,distance=..4,nbt={inGround:0b}]
kill @e[type=minecraft:firework_rocket,distance=..4,nbt={ShotAtAngle:1b}]
# a fuse is already burning: ignore
execute if score @s bitch_fuse matches 1.. run return 0
scoreboard players set @s bitch_fuse 40
playsound dueris:allahuakbarboom player @a ~ ~ ~ 4 1
