# the first target decides where the ray ends: now for normal shots, +#mode blocks for Piercing II-IV
scoreboard players set #first bitch_tmp 1
scoreboard players operation #limit bitch_tmp = #d bitch_tmp
scoreboard players operation #limit bitch_tmp += #mode bitch_tmp
